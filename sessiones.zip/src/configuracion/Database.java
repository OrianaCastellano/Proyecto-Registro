package configuracion;

public class Database {
	private String url;
	private String password;
	private String user;
	private String driver;
	
	public Database() {
		//ruta de conexion a la base de datos mediante el controlador de java JDBC
		this.url = "jdbc:postgresql://ec2-54-160-120-28.compute-1.amazonaws.com:5432/ddh8p0melq8s33";
		//usuario de la base de datos
		this.user="oohwskqksovasu";
		//contrase�a de la base de datos
		this.password="8d8b2a25f825791a1eee1bedc520bdddf542c42266884ea4dd53b2efd09d8bfd";
		//parametro de conexion al driver para postgres de java
		this.driver="org.postgresql.Driver";
	}

// las funciones siguientes corresponden a los getters que permitan devolver el valor de las variables declasradas dentro de la clase
	public String getUrl() {
		return url;
	}

	public String getPassword() {
		return password;
	}

	public String getUser() {
		return user;
	}

	public String getDriver() {
		return driver;
	}

	
}

package servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


/**
 * Servlet implementation class IndexServlet
 */
@WebServlet("/IndexServlet")
public class IndexServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session= (HttpSession) request.getSession();
		System.out.print("Cargando el index");
		if (session.getAttribute("status") == null || request.getParameter("cerrar") != null) { 
		    // No session present, you can create yourself
			session.invalidate();
			System.out.print("sesion no iniciada");
			RequestDispatcher rd = request.getRequestDispatcher("index.html"); //redireccionar
			rd.forward(request, response);
			
		} else if((Boolean)session.getAttribute("status")){
				System.out.print("la session existe");
				response.sendRedirect("Panel");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
